package kr.co.tjoeun.beans;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TestBean {
	private String data1;
	private int data2;
	private double data3;
	private boolean data4;
}
