# 스프링 레거시를 배우는 기초단계

## [0607](https://github.com/nxx5xxx/spring/blob/master/0607.md)

    getObjectParameter
    ViewResolver
    CommandObject
    FormCustomTag
    FormCustomTag2
    FormCustomTag3

## [0609](https://github.com/nxx5xxx/spring/blob/master/0609.md)

    FormCustomTag3
    RedirectForward
    RequestScope
    RequestScopeBean
    RequestScopeBeanXml

## [0612](https://github.com/nxx5xxx/spring/blob/master/0612.md)
    SessionScope
    SessionScopeBean - (자바 설정방식)
    SessionScopeXml - (xml설정방식)
    ApplicationScope
    ApplicationScopeJava
    ApplicationScopeXml
    Cookie

## [0613](https://github.com/nxx5xxx/spring/blob/master/0613.md)
    1 properties
    2 message (JAVA 설정) :  수정 후 공유
    3 messageXml (xml 설정)

## [0614](https://github.com/nxx5xxx/spring/blob/master/0614.md)
    validate
    validate2
    JSR_303
    JSR_380
    Validator (Custom Validation)

## [0616](https://github.com/nxx5xxx/spring/blob/master/0616.md)
    MyBatis
    RestfulAPI

## [0619](https://github.com/nxx5xxx/spring/blob/master/0619.md)
    Interceptor
    InterceptorXml
    ExceptionHandling
    boardProject
    boardProject2