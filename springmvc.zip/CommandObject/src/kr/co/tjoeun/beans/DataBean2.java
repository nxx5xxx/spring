package kr.co.tjoeun.beans;

public class DataBean2 {

	private String number3;
	private String number4;
	public String getNumber3() {
		return number3;
	}
	public void setNumber3(String number3) {
		this.number3 = number3;
	}
	public String getNumber4() {
		return number4;
	}
	public void setNumber4(String number4) {
		this.number4 = number4;
	}
	

	
	
}
