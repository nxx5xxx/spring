package kr.co.tjoeun.beans;

public class DataBean3 {

	private String number5;
	private String number6;
	public String getNumber5() {
		return number5;
	}
	public void setNumber5(String number5) {
		this.number5 = number5;
	}
	public String getNumber6() {
		return number6;
	}
	public void setNumber6(String number6) {
		this.number6 = number6;
	}

	

	
	
}
