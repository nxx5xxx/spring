package kr.co.tjoeun.config;

import org.springframework.context.annotation.Configuration;

//상속이 없음 : 프로젝트 작업시 사용할 bean을 정의하는 클래스
//root_context.xml의 역할
@Configuration
public class RootAppContext {

}
