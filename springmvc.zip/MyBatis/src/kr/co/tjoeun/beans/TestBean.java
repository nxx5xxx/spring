package kr.co.tjoeun.beans;

import lombok.Data;

@Data
public class TestBean {
	private String data1;
	private String data2;
	private String data3;
}
